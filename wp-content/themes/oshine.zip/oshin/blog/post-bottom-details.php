<?php global $meta_sep; ?>
<nav class="post-nav meta-font secondary_text">
	<ul class="clearfix">	
		<li class="post-meta post-category"><?php _e('Under :','oshin'); ?><?php be_themes_category_list($id); ?></li>
	</ul>
</nav>